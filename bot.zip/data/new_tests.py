#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Модуль с данными для новых психологических тестов
"""

# Импортируем структуру новых тестов
import sys
import os
sys.path.append('/home/ubuntu')
from new_tests_structure import NEW_TESTS_INFO

# Категории новых тестов
NEW_TEST_CATEGORIES = {
    "mood": {
        "name": "Настроение и Эмоциональное состояние",
        "description": "Тесты для оценки настроения, эмоционального благополучия, тревоги и депрессии.",
        "tests": ["hads", "who5"]
    },
    "stress": {
        "name": "Стресс и Выгорание",
        "description": "Тесты для оценки уровня стресса, выгорания и панических состояний.",
        "tests": ["pss", "burnout", "panic"]
    },
    "self": {
        "name": "Самооценка и Личностные особенности",
        "description": "Тесты для оценки самоуважения, прокрастинации, копинг-стратегий и качества сна.",
        "tests": ["rosenberg", "procrastination", "coping", "sleep"]
    },
    "specific": {
        "name": "Специфические состояния",
        "description": "Тесты для оценки специфических состояний и привычек.",
        "tests": ["audit"]
    }
}

# Функция для преобразования структуры тестов в формат, совместимый с ботом
def convert_test_format(test_key, test_data):
    """
    Преобразует структуру теста из NEW_TESTS_INFO в формат, совместимый с ботом
    """
    # Базовая информация о тесте
    converted_test = {
        "name": test_data["name"],
        "description": test_data["description"],
        "time": test_data["time"],
        "questions": [],
        "calculation_type": test_data.get("calculation", "sum")
    }
    
    # Преобразование вопросов
    for i, question in enumerate(test_data["questions"]):
        converted_question = {
            "text": question["text"],
            "answers": list(question["options"].values()),
            "scores": [int(score) for score in question["options"].keys()]
        }
        
        # Добавляем информацию о подшкале, если есть
        if "subscale" in question:
            converted_question["subscale"] = question["subscale"]
        
        # Добавляем информацию о реверсивном вопросе, если есть
        if question.get("reverse", False):
            converted_question["reverse"] = True
        
        converted_test["questions"].append(converted_question)
    
    # Преобразование интерпретаций
    if isinstance(test_data["interpretations"], dict):
        # Для тестов с подшкалами
        converted_test["subscales"] = list(test_data["interpretations"].keys())
        converted_test["interpretations"] = {}
        
        for subscale, interpretations in test_data["interpretations"].items():
            converted_test["interpretations"][subscale] = []
            for threshold, text in interpretations:
                converted_test["interpretations"][subscale].append({
                    "min_score": threshold,
                    "max_score": 100,  # Максимальное значение, будет корректироваться при обработке
                    "text": text
                })
            
            # Корректируем max_score для каждой интерпретации
            for i in range(len(converted_test["interpretations"][subscale]) - 1):
                converted_test["interpretations"][subscale][i]["max_score"] = converted_test["interpretations"][subscale][i+1]["min_score"] - 1
    else:
        # Для тестов с общим результатом
        converted_test["interpretations"] = []
        for threshold, text in test_data["interpretations"]:
            converted_test["interpretations"].append({
                "min_score": threshold,
                "max_score": 100,  # Максимальное значение, будет корректироваться при обработке
                "text": text
            })
        
        # Корректируем max_score для каждой интерпретации
        for i in range(len(converted_test["interpretations"]) - 1):
            converted_test["interpretations"][i]["max_score"] = converted_test["interpretations"][i+1]["min_score"] - 1
    
    # Добавляем флаг чувствительности, если есть
    if test_data.get("sensitive", False):
        converted_test["sensitive"] = True
    
    return converted_test

# Преобразуем все новые тесты в формат бота
NEW_TESTS = {}
for test_key, test_data in NEW_TESTS_INFO.items():
    NEW_TESTS[test_key] = convert_test_format(test_key, test_data)
