#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Модуль для сбора и анализа статистики использования бота
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class StatsCollector:
    """
    Класс для сбора и анализа статистики использования бота
    """
    
    def __init__(self, database):
        """
        Инициализация коллектора статистики
        
        Args:
            database: Экземпляр класса Database для работы с базой данных
        """
        self.db = database
    
    def log_command_usage(self, user_id: int, command: str) -> bool:
        """
        Записывает использование команды в статистику
        
        Args:
            user_id: ID пользователя
            command: Использованная команда
            
        Returns:
            True, если операция выполнена успешно
        """
        try:
            self.db.connect()
            
            # Обновляем last_activity пользователя
            query_str = "UPDATE users SET last_activity = ? WHERE user_id = ?"
            if self.db.db_type == "postgresql":
                query_str = query_str.replace("?", "%s")
            
            self.db.execute(query_str, (datetime.now(), user_id))
            
            # Записываем использование команды
            query_str = "INSERT INTO command_logs (user_id, command) VALUES (?, ?)"
            if self.db.db_type == "postgresql":
                query_str = query_str.replace("?", "%s")
            
            self.db.execute(query_str, (user_id, command))
            
            logger.info(f"Записано использование команды {command} пользователем {user_id}")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка при записи статистики использования команды: {e}")
            return False
            
        finally:
            self.db.disconnect()
    
    def get_active_users(self, days: int = 7) -> List[Dict[str, Any]]:
        """
        Получает список активных пользователей за указанный период
        
        Args:
            days: Количество дней для анализа
            
        Returns:
            Список словарей с информацией о пользователях
        """
        try:
            self.db.connect()
            
            if self.db.db_type == "sqlite":
                query_str = """
                SELECT u.user_id, u.username, u.first_name, u.last_name, u.last_activity,
                       COUNT(c.log_id) as command_count
                FROM users u
                LEFT JOIN command_logs c ON u.user_id = c.user_id
                WHERE u.last_activity >= datetime('now', ?)
                GROUP BY u.user_id
                ORDER BY command_count DESC
                """
                days_param = f"-{days} days"
            elif self.db.db_type == "postgresql":
                query_str = """
                SELECT u.user_id, u.username, u.first_name, u.last_name, u.last_activity,
                       COUNT(c.log_id) as command_count
                FROM users u
                LEFT JOIN command_logs c ON u.user_id = c.user_id
                WHERE u.last_activity >= NOW() - INTERVAL %s
                GROUP BY u.user_id
                ORDER BY command_count DESC
                """
                days_param = f"{days} days"
            
            users = self.db.query(query_str, (days_param,))
            
            return users
            
        except Exception as e:
            logger.error(f"Ошибка при получении активных пользователей: {e}")
            return []
            
        finally:
            self.db.disconnect()
    
    def get_command_usage_stats(self, days: int = 7) -> List[Dict[str, Any]]:
        """
        Получает статистику использования команд за указанный период
        
        Args:
            days: Количество дней для анализа
            
        Returns:
            Список словарей со статистикой команд
        """
        try:
            self.db.connect()
            
            if self.db.db_type == "sqlite":
                query_str = """
                SELECT command, COUNT(*) as count, COUNT(DISTINCT user_id) as unique_users
                FROM command_logs
                WHERE timestamp >= datetime('now', ?)
                GROUP BY command
                ORDER BY count DESC
                """
                days_param = f"-{days} days"
            elif self.db.db_type == "postgresql":
                query_str = """
                SELECT command, COUNT(*) as count, COUNT(DISTINCT user_id) as unique_users
                FROM command_logs
                WHERE timestamp >= NOW() - INTERVAL %s
                GROUP BY command
                ORDER BY count DESC
                """
                days_param = f"{days} days"
            
            stats = self.db.query(query_str, (days_param,))
            
            return stats
            
        except Exception as e:
            logger.error(f"Ошибка при получении статистики использования команд: {e}")
            return []
            
        finally:
            self.db.disconnect()
    
    def get_daily_usage_stats(self, days: int = 30) -> List[Dict[str, Any]]:
        """
        Получает ежедневную статистику использования бота
        
        Args:
            days: Количество дней для анализа
            
        Returns:
            Список словарей с ежедневной статистикой
        """
        try:
            self.db.connect()
            
            if self.db.db_type == "sqlite":
                query_str = """
                SELECT DATE(timestamp) as day,
                       COUNT(*) as command_count,
                       COUNT(DISTINCT user_id) as unique_users
                FROM command_logs
                WHERE timestamp >= datetime('now', ?)
                GROUP BY DATE(timestamp)
                ORDER BY day
                """
                days_param = f"-{days} days"
            elif self.db.db_type == "postgresql":
                query_str = """
                SELECT DATE(timestamp) as day,
                       COUNT(*) as command_count,
                       COUNT(DISTINCT user_id) as unique_users
                FROM command_logs
                WHERE timestamp >= NOW() - INTERVAL %s
                GROUP BY DATE(timestamp)
                ORDER BY day
                """
                days_param = f"{days} days"
            
            stats = self.db.query(query_str, (days_param,))
            
            return stats
            
        except Exception as e:
            logger.error(f"Ошибка при получении ежедневной статистики: {e}")
            return []
            
        finally:
            self.db.disconnect()
    
    def get_user_retention(self, days: int = 30) -> Dict[str, Any]:
        """
        Анализирует удержание пользователей
        
        Args:
            days: Количество дней для анализа
            
        Returns:
            Словарь с данными об удержании пользователей
        """
        try:
            self.db.connect()
            
            # Общее количество пользователей
            total_query = "SELECT COUNT(*) as count FROM users"
            total_users_result = self.db.query(total_query)
            total_users = total_users_result[0]["count"] if total_users_result else 0
            
            # Активные пользователи за последний день
            if self.db.db_type == "sqlite":
                day_query = """
                    SELECT COUNT(DISTINCT user_id) as count
                    FROM users
                    WHERE last_activity >= datetime('now', '-1 day')
                """
            elif self.db.db_type == "postgresql":
                day_query = """
                    SELECT COUNT(DISTINCT user_id) as count
                    FROM users
                    WHERE last_activity >= NOW() - INTERVAL '1 day'
                """
            
            day_active_result = self.db.query(day_query)
            day_active = day_active_result[0]["count"] if day_active_result else 0
            
            # Активные пользователи за последнюю неделю
            if self.db.db_type == "sqlite":
                week_query = """
                    SELECT COUNT(DISTINCT user_id) as count
                    FROM users
                    WHERE last_activity >= datetime('now', '-7 day')
                """
            elif self.db.db_type == "postgresql":
                week_query = """
                    SELECT COUNT(DISTINCT user_id) as count
                    FROM users
                    WHERE last_activity >= NOW() - INTERVAL '7 days'
                """
            
            week_active_result = self.db.query(week_query)
            week_active = week_active_result[0]["count"] if week_active_result else 0
            
            # Активные пользователи за последний месяц
            if self.db.db_type == "sqlite":
                month_query = """
                    SELECT COUNT(DISTINCT user_id) as count
                    FROM users
                    WHERE last_activity >= datetime('now', ?)
                """
                days_param = f"-{days} days"
            elif self.db.db_type == "postgresql":
                month_query = """
                    SELECT COUNT(DISTINCT user_id) as count
                    FROM users
                    WHERE last_activity >= NOW() - INTERVAL %s
                """
                days_param = f"{days} days"
            
            month_active_result = self.db.query(month_query, (days_param,))
            month_active = month_active_result[0]["count"] if month_active_result else 0
            
            # Расчет показателей удержания
            day_retention = round(day_active / total_users * 100, 2) if total_users > 0 else 0
            week_retention = round(week_active / total_users * 100, 2) if total_users > 0 else 0
            month_retention = round(month_active / total_users * 100, 2) if total_users > 0 else 0
            
            return {
                "total_users": total_users,
                "day_active": day_active,
                "week_active": week_active,
                "month_active": month_active,
                "day_retention": day_retention,
                "week_retention": week_retention,
                "month_retention": month_retention
            }
            
        except Exception as e:
            logger.error(f"Ошибка при анализе удержания пользователей: {e}")
            return {
                "total_users": 0,
                "new_users": 0,
                "active_users": 0,
                "returning_users": 0,
                "retention_rate": 0
            }
            
        finally:
            self.db.disconnect()
    
    def get_feature_usage_stats(self, days: int = 30) -> Dict[str, Any]:
        """
        Анализирует использование различных функций бота
        
        Args:
            days: Количество дней для анализа
            
        Returns:
            Словарь с данными об использовании функций
        """
        try:
            self.db.connect()
            
            # Статистика по тестам
            if self.db.db_type == "sqlite":
                tests_query = """
                    SELECT COUNT(*) as count
                    FROM test_results
                    WHERE date_taken >= datetime('now', ?)
                """
                days_param = f"-{days} days"
            elif self.db.db_type == "postgresql":
                tests_query = """
                    SELECT COUNT(*) as count
                    FROM test_results
                    WHERE date_taken >= NOW() - INTERVAL %s
                """
                days_param = f"{days} days"
            
            tests_result = self.db.query(tests_query, (days_param,))
            tests_count = tests_result[0]["count"] if tests_result else 0
            
            # Статистика по отслеживанию настроения
            if self.db.db_type == "sqlite":
                mood_query = """
                    SELECT COUNT(*) as count
                    FROM mood_tracking
                    WHERE date_recorded >= datetime('now', ?)
                """
            elif self.db.db_type == "postgresql":
                mood_query = """
                    SELECT COUNT(*) as count
                    FROM mood_tracking
                    WHERE date_recorded >= NOW() - INTERVAL %s
                """
            
            mood_result = self.db.query(mood_query, (days_param,))
            mood_count = mood_result[0]["count"] if mood_result else 0
            
            # Статистика по вопросам
            if self.db.db_type == "sqlite":
                questions_query = """
                    SELECT COUNT(*) as count
                    FROM anonymous_questions
                    WHERE date_asked >= datetime('now', ?)
                """
            elif self.db.db_type == "postgresql":
                questions_query = """
                    SELECT COUNT(*) as count
                    FROM anonymous_questions
                    WHERE date_asked >= NOW() - INTERVAL %s
                """
            
            questions_result = self.db.query(questions_query, (days_param,))
            questions_count = questions_result[0]["count"] if questions_result else 0
            
            # Формируем результат
            result = {
                "tests_completed": tests_count,
                "mood_entries": mood_count,
                "questions_asked": questions_count
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Ошибка при анализе использования функций: {e}")
            return {
                "tests_completed": 0,
                "mood_entries": 0,
                "questions_asked": 0
            }
            
        finally:
            self.db.disconnect()
