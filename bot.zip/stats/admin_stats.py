#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Модуль для административных команд статистики
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler

from config import ADMIN_USER_ID
from stats.stats_collector import StatsCollector

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Константы для состояний разговора
SELECTING_STATS_PERIOD = range(1)

class AdminStats:
    """
    Класс для обработки административных команд статистики
    """
    
    def __init__(self, database):
        """
        Инициализация обработчика административных команд
        
        Args:
            database: Экземпляр класса Database для работы с базой данных
        """
        self.db = database
        self.stats_collector = StatsCollector(database)
    
    async def stats_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """
        Обрабатывает команду /stats
        
        Args:
            update: Объект обновления Telegram
            context: Контекст обработчика
            
        Returns:
            Следующее состояние разговора
        """
        user_id = update.effective_user.id
        
        # Проверяем, является ли пользователь администратором
        if user_id != ADMIN_USER_ID:
            await update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return ConversationHandler.END
        
        # Логируем использование команды
        self.stats_collector.log_command_usage(user_id, "/stats")
        
        # Создаем клавиатуру для выбора периода
        keyboard = [
            [
                InlineKeyboardButton("За сегодня", callback_data="stats_period_1"),
                InlineKeyboardButton("За 7 дней", callback_data="stats_period_7")
            ],
            [
                InlineKeyboardButton("За 30 дней", callback_data="stats_period_30"),
                InlineKeyboardButton("За всё время", callback_data="stats_period_all")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "📊 *Статистика бота*\n\n"
            "Выберите период для анализа:",
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )
        
        return SELECTING_STATS_PERIOD
    
    async def select_stats_period(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """
        Обрабатывает выбор периода для статистики
        
        Args:
            update: Объект обновления Telegram
            context: Контекст обработчика
            
        Returns:
            Следующее состояние разговора
        """
        query = update.callback_query
        await query.answer()
        
        # Получаем выбранный период
        period_data = query.data.replace("stats_period_", "")
        
        if period_data == "all":
            days = None
            period_text = "за всё время"
        else:
            days = int(period_data)
            period_text = f"за последние {days} дней"
        
        # Получаем статистику
        await self._send_stats_report(update, context, days, period_text)
        
        return ConversationHandler.END
    
    async def active_users_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """
        Обрабатывает команду /active_users
        
        Args:
            update: Объект обновления Telegram
            context: Контекст обработчика
        """
        user_id = update.effective_user.id
        
        # Проверяем, является ли пользователь администратором
        if user_id != ADMIN_USER_ID:
            await update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return
        
        # Логируем использование команды
        self.stats_collector.log_command_usage(user_id, "/active_users")
        
        # Получаем период из аргументов команды или используем значение по умолчанию
        try:
            days = int(context.args[0]) if context.args else 7
        except (ValueError, IndexError):
            days = 7
        
        # Получаем активных пользователей
        active_users = self.stats_collector.get_active_users(days)
        
        if not active_users:
            await update.message.reply_text(
                f"📊 *Активные пользователи за последние {days} дней*\n\n"
                "Активных пользователей не найдено.",
                parse_mode="Markdown"
            )
            return
        
        # Формируем отчет
        report = f"📊 *Активные пользователи за последние {days} дней*\n\n"
        report += f"Всего активных пользователей: {len(active_users)}\n\n"
        
        # Добавляем информацию о топ-10 пользователях
        report += "*Топ-10 пользователей по активности:*\n"
        for i, user in enumerate(active_users[:10], 1):
            username = user.get("username", "Нет")
            first_name = user.get("first_name", "Неизвестно")
            last_name = user.get("last_name", "")
            full_name = f"{first_name} {last_name}".strip()
            
            report += f"{i}. ID: {user['user_id']}, Имя: {full_name}, "
            report += f"Username: @{username}, Команд: {user['command_count']}\n"
        
        await update.message.reply_text(
            report,
            parse_mode="Markdown"
        )
    
    async def commands_stats_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """
        Обрабатывает команду /commands_stats
        
        Args:
            update: Объект обновления Telegram
            context: Контекст обработчика
        """
        user_id = update.effective_user.id
        
        # Проверяем, является ли пользователь администратором
        if user_id != ADMIN_USER_ID:
            await update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return
        
        # Логируем использование команды
        self.stats_collector.log_command_usage(user_id, "/commands_stats")
        
        # Получаем период из аргументов команды или используем значение по умолчанию
        try:
            days = int(context.args[0]) if context.args else 7
        except (ValueError, IndexError):
            days = 7
        
        # Получаем статистику использования команд
        commands_stats = self.stats_collector.get_command_usage_stats(days)
        
        if not commands_stats:
            await update.message.reply_text(
                f"📊 *Статистика использования команд за последние {days} дней*\n\n"
                "Данных не найдено.",
                parse_mode="Markdown"
            )
            return
        
        # Формируем отчет
        report = f"📊 *Статистика использования команд за последние {days} дней*\n\n"
        
        # Добавляем информацию о командах
        for i, stat in enumerate(commands_stats, 1):
            report += f"{i}. {stat['command']}: {stat['count']} раз "
            report += f"({stat['unique_users']} уникальных пользователей)\n"
        
        await update.message.reply_text(
            report,
            parse_mode="Markdown"
        )
    
    async def _send_stats_report(self, update: Update, context: ContextTypes.DEFAULT_TYPE, days: Optional[int], period_text: str) -> None:
        """
        Отправляет полный отчет о статистике
        
        Args:
            update: Объект обновления Telegram
            context: Контекст обработчика
            days: Количество дней для анализа (None для всего времени)
            period_text: Текстовое описание периода
        """
        query = update.callback_query
        
        # Получаем статистику
        if days is None:
            # Для всего времени используем большое значение
            days = 3650  # ~10 лет
        
        # Получаем данные об удержании пользователей
        retention_data = self.stats_collector.get_user_retention(days)
        
        # Получаем данные об использовании функций
        feature_usage = self.stats_collector.get_feature_usage_stats(days)
        
        # Получаем статистику использования команд
        commands_stats = self.stats_collector.get_command_usage_stats(days)
        
        # Формируем отчет
        report = f"📊 *Общая статистика бота {period_text}*\n\n"
        
        # Данные о пользователях
        report += "*Пользователи:*\n"
        report += f"• Всего пользователей: {retention_data['total_users']}\n"
        
        # Проверяем наличие ключей в словаре
        if 'day_active' in retention_data:
            report += f"• Активных за день: {retention_data['day_active']}\n"
        if 'week_active' in retention_data:
            report += f"• Активных за неделю: {retention_data['week_active']}\n"
        if 'month_active' in retention_data:
            report += f"• Активных за месяц: {retention_data['month_active']}\n"
        if 'day_retention' in retention_data:
            report += f"• Удержание (день): {retention_data['day_retention']}%\n"
        if 'week_retention' in retention_data:
            report += f"• Удержание (неделя): {retention_data['week_retention']}%\n"
        if 'month_retention' in retention_data:
            report += f"• Удержание (месяц): {retention_data['month_retention']}%\n"
        
        report += "\n"
        
        # Данные об использовании функций
        report += "*Использование функций:*\n"
        report += f"• Пройдено тестов: {feature_usage['tests_completed']}\n"
        report += f"• Записей о настроении: {feature_usage['mood_entries']}\n"
        report += f"• Задано вопросов: {feature_usage['questions_asked']}\n\n"
        
        # Топ-5 команд
        report += "*Топ-5 команд:*\n"
        for i, stat in enumerate(commands_stats[:5], 1):
            report += f"{i}. {stat['command']}: {stat['count']} раз\n"
        
        await query.edit_message_text(
            report,
            parse_mode="Markdown"
        )
