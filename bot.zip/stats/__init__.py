#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Инициализация модуля статистики
"""

from .stats_collector import StatsCollector
from .admin_stats import AdminStats

__all__ = ['StatsCollector', 'AdminStats']
