#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Конфигурационный файл для телеграм-бота
"""

import os
from dotenv import load_dotenv

# Загружаем переменные окружения из файла .env
load_dotenv()

# Токен бота
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

# ID администратора
ADMIN_USER_ID = int(os.getenv("ADMIN_USER_ID", "0"))

# Настройки базы данных
DATABASE = {
    "type": os.getenv("DB_TYPE", "sqlite"),  # sqlite или postgresql
    "sqlite_path": os.getenv("DB_SQLITE_PATH", "bot_database.db"),
    "postgresql": {
        "host": os.getenv("DB_HOST", "localhost"),
        "port": int(os.getenv("DB_PORT", "5432")),
        "database": os.getenv("DB_NAME", "telegram_bot"),
        "user": os.getenv("DB_USER", "postgres"),
        "password": os.getenv("DB_PASSWORD", "")
    }
}

# Настройки уведомлений
NOTIFICATION_SETTINGS = {
    "daily_reminder_time": "09:00",  # Время ежедневного напоминания
    "daily_reminder_enabled": True,  # Включены ли ежедневные напоминания
    "new_question_emoji": "❓",  # Эмодзи для новых вопросов
    "answered_question_emoji": "✅",  # Эмодзи для отвеченных вопросов
    "mood_tracking_reminder_time": "20:00",  # Время напоминания об отслеживании настроения
    "mood_tracking_reminder_enabled": True  # Включены ли напоминания об отслеживании настроения
}

# Настройки тестов
TEST_SETTINGS = {
    "anxiety_test_threshold": 10,  # Порог для теста на тревожность
    "depression_test_threshold": 10,  # Порог для теста на депрессию
    "stress_test_threshold": 15  # Порог для теста на стресс
}

# Настройки отслеживания настроения
MOOD_TRACKING_SETTINGS = {
    "mood_emojis": {
        "excellent": "😁",
        "good": "🙂",
        "neutral": "😐",
        "bad": "😔",
        "terrible": "😢"
    },
    "mood_texts": {
        "excellent": "Отлично",
        "good": "Хорошо",
        "neutral": "Нормально",
        "bad": "Плохо",
        "terrible": "Ужасно"
    }
}

# Для обратной совместимости
MOOD_EMOJIS = MOOD_TRACKING_SETTINGS["mood_emojis"]

# Информация о боте
BOT_INFO = {
    "name": "Психологический помощник",
    "version": "1.0.0",
    "description": "Бот для психологической поддержки и самопомощи",
    "author": "Юрий Александрович Лысенко, психотерапевт, врач-психиатр высшей категории",
    "website": "https://t.me/psihotips"
}

# Настройки для ограничения частоты использования команд
RATE_LIMIT_SETTINGS = {
    "test_command": 3600,  # Ограничение для команды /test (в секундах)
    "test": 3600,  # Для обратной совместимости
    "mood_command": 300,  # Ограничение для команды /mood (в секундах)
    "question_command": 600,  # Ограничение для команды /question (в секундах)
    "daily_tip": 86400,  # Ограничение для ежедневных советов (24 часа)
    "anonymous_question": 600  # Ограничение для анонимных вопросов (10 минут)
}

# Для обратной совместимости
RATE_LIMIT = RATE_LIMIT_SETTINGS

# Настройки для техник самопомощи
SELF_HELP_SETTINGS = {
    "techniques_per_page": 5,  # Количество техник на странице
    "max_technique_length": 1000  # Максимальная длина описания техники
}

# Настройки для анонимных вопросов
ANONYMOUS_QUESTIONS_SETTINGS = {
    "max_question_length": 500,  # Максимальная длина вопроса
    "max_questions_per_day": 3  # Максимальное количество вопросов в день
}

# Настройки для логирования
LOGGING_SETTINGS = {
    "log_file": "bot.log",
    "log_level": "INFO"
}
